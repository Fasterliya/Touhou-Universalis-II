# 东方风云 MOD 1.3 适配 — 崩溃日志包说明

> 打包时间：2026-08-02
> 适用：游戏 1.3.11 / MOD 1.2.3（适配中）

## 包内文件

| 文件 | 说明 |
|------|------|
| `debug.log` | 主调试日志（加载、初始化、运行时）|
| `error.log` | 错误日志（含崩溃前断言）|
| `ai.log` | AI 行为日志（无效命令刷屏）|
| `game.log` | 游戏初始化日志（TH 国家初始化状态）|
| `最新崩溃_exception.txt` | 最新崩溃（17:29）的异常栈 |
| `崩溃排查报告.md` | 完整排查过程与根因分析（先读这个）|

## 关键结论速览

### 崩溃现象
- 进游戏正常，走时间数秒后闪退（无弹窗）
- 崩溃类型：`C0000005 ACCESS_VIOLATION` @ 同一地址（确定性内存破坏）
- 前兆：`pdx_assert: Tried to reallocate a pre-allocated buffer`

### 已定位并修复的根因（4 类）
1. **1.2 defines 覆盖 1.3** → 缺失新 define → 除零崩溃（已修：最小覆盖集方案）
2. **setup 模板引用其他 MOD 的 key**（`dop_favor_the_ruler_miku_ver`）→ AI 外交目标全面失败（已修）
3. **TH 国家段缩进深 1 级**（合并时转换错误，2tab vs base 1tab）→ 95 国全部未初始化，症状 `has not capital set` ×95（已修）⭐核心根因
4. **TH 国家数据错误**：领地冲突 ×3、重复 include ×2、首都归属 ×1（已修）

### 未解决（残余）
- TH 国家初始化成功后仍崩溃：**AI 无效命令刷屏**（change_trade_capacity ×40 等）→ buffer 崩溃
- 触发源未定位，候选：TH 市场 AI 操作 / 2D Portrait 基因缺失 / TH 文化人口不匹配

## 日志中值得注意的条目

- `error.log`：`Tried to reallocate a pre-allocated buffer`（崩溃前兆）
- `ai.log`：`[AI Warning] AI tried to execute invalid command` ×76（类型见报告）
- `game.log`：TH 国家初始化状态（修复后 capital/government 全 0 错误）
- `error.log`：`could not find attribute` ×110（2D Portrait 基因与 base 1.3 属性不匹配）
